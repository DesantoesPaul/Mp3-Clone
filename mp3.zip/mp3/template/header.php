<?php
if(empty($title)) $title = $c['title'].' - '.$c['meta'];
if(empty($desc)) $desc = $c['desc'];
if(empty($keywords)) $keywords = $c['keys'];
?>
<head>
<script src="https://accounts.google.com/gsi/client" async defer></script>
<div id="g_id_onload"
     data-client_id="481913602305-bddp4b8u9i1bi1cpe3ceeou5nk1ekrsl.apps.googleusercontent.com"
     data-auto_select="true"
     data-login_uri="https://www.vevioz.com/login-with.php?provider=Google"
	 data-cancel_on_tap_outside="false">
</div>
    <meta charset="utf-8">
	<html lang="en">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $title;?></title>
	<base href="<?= $c['site'];?>">
	<meta name="robots" content="index,follow">
	<meta name="keywords" content="<?= $keywords;?>">
	<meta name="description" content="<?= $desc;?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#1676c2">
    <meta property="og:site_name" content="<?= $title;?>">
    <meta property="og:url" content="<?= $c['site'];?>">
    <meta property="og:title" content="<?= $title;?>">
    <meta property="og:image" content="<?= $c['cdns'];?>/img/graph.png">
	<meta property="fb:app_id" content="315792432626012" />
    <meta property="og:description" content="<?= $desc.' '.$keywords;?>">
    <meta property="og:type" content="website">
	<link rel="icon" href="<?= $c['cdns'];?>/images/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="<?= $c['cdns'];?>/assets/fonts/font-awesome.min.css" >
    <?php hscript($c);?>
    <script src="<?= $c['cdns'];?>/assets/jquery.min.js"></script>
    <script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebSite",
    "Headline": "<?= $title;?>",
    "description": "<?= $desc.' '.$keywords;?>.
"
    }
    </script>
</head><body>
 <div id="nav">
  <a href="/">Home</a><a href="/cutter/">FAQ</a><a href="https://api.vevioz.com/developers" target="_blank">Contact</a><a href="https://addons.vevioz.com" target="_blank">News</a>
 </div>
 <div id="content">
    <a href=""><img id="logo" src="/images/logo.png" alt="MP3 Duke"></a>