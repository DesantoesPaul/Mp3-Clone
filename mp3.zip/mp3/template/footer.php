<div id="footer">
  <a href="/contact/">Contact</a><a href="/privacy-policy/">Privacy</a><a href="/special-rightholders-accounts/">SRA</a><a href="/terms-of-use/">TOS</a>
 </div>
</body>
<?php
echo fscript($c);
?>
</html>
</body>
</html>