<form method="post">
   <input id="query" type="text" name="query" autocomplete="off" autofocus>
   <button id="button" type="submit"><i class="fa fa-search"></i></button>
   <div class="clear"></div>
   <div id="suggestions">
   </div>
  </form> <div id="form_text">
   By pressing "Search" you confirm your consent to our <a href="terms-of-use/">Terms of Use</a>.
  </div>
  <a id="control_sources" href="#">manage sources (<span>2</span>/8)</a>
  <div id="sources">
   <div id="left">
    <a id="yt" href="#" class="enabled">YouTube</a>
    <a id="vk" href="#" class="disabled">vk</a>
    <a id="4s" href="#" class="disabled">4shared</a>
    <a id="ar" href="#" class="disabled">Archive</a>
   </div>
   <div id="right">
    <a id="sc" href="#" class="enabled">Soundcloud</a>
    <a id="yd" href="#" class="disabled">Yandex</a>
    <a id="pd" href="#" class="disabled">PromoDJ</a>
    <a id="pd" href="#" class="disabled">Spotify</a>
   </div>
   <div class="clear"></div>
  </div>
  <div id="load">
   <i class="fa fa-spinner fa-spin"></i>
  </div>