<?php
$c = array();
$c['title'] = 'MP3 Duke';
$c['meta'] = 'Fast and Free MP3 Downloads';
$c['desc'] = 'Search for your favorite songs from multiple online sources and download them in the best possible quality for free. There is no registration needed.';
$c['keys'] = 'free,mp3,downloads';
$c['site'] = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$c['cdns'] = 'https://assets.vevioz.com';
$c['email'] = 'mentasolutions7@gmail.com';
$GLOBALS['c'] = $c;