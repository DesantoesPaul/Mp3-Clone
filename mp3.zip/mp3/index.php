<?php
require_once('_autoload.php');
function hscript($c){
  echo '<link rel="stylesheet" type="text/css" href="'.$c['cdns'].'/assets/main.css" >';
}
include('template/header.php');
include('template/form.php');
?>
<div id="text">
   <h1>Fast and Free MP3 Downloads </h1>  
   <p>Welcome to MP3 Duke, we offer you the easiest way to download high-quality MP3 songs.
</p> 
   <p> 
   You can get access to MP3 files of your choice without hassle. Have you been wondering or racking your brains about where to access music audios or even podcasts? Are you searching for the best free MP3 download sites? There is no need to search anymore! Given what this free MP3 music downloader can offer, you will be getting easy access to MP3 files. Just find your favorite songs and start downloading without any limitations. You are just a few clicks away from enjoying such songs today.

   </p>
   <p>
   You want to listen to your favourite music everywhere and at any time? Then welcome to MP3 Duke! The website where you can find every song you like – no matter what genre.All you need to do is to insert a keyword of songs, artists, lyrics or paste the link on the search box. Then, choose the best quality music to download on your device.

   </p>
   <p>
   With our help you can take it everywhere you like without paying a cent. We offer you a free way to download your songs for your individual playlist that inspires you. You can save them on every other device to play them in your car, on a party or just at home.
   </p>
   <p>Our search engine shows you a huge offer of songs and video that are available on the web. There is no need to register or pay for a hidden subscription. We are all open and honest about our performance and service quality.</p>
   <p>
   If you have any questions, feel free to <a href="/contact/">Contact us</a>. We don’t bite!

   </p>
  </div>

</div>
</div>
<?php
function fscript($c){
echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/iframe-resizer/4.3.2/iframeResizer.min.js"></script><script src="https://assets.vevioz.com/vendor/main.js?v=1329019219"></script>';
}
include('template/footer.php');
?>