HOW TO CONFIGURE
================================================== =====================================
This AGC script was developed by https://developers.vevioz.com

Author: Nadia Verona

Contact: https://www.vevioz.com/Nadia
================================================== =====================================

Thank's